14 ESTÉTICA AUTOMOTIVA — SITE

Arquivos:
- index.html
- assets/logo.png

O site é estático (HTML + CSS), então pode ser publicado gratuitamente em serviços de hospedagem de sites estáticos.

Dados usados a partir do material enviado:
WhatsApp: (21) 97310-5649
Instagram: @14esteticaautomotiva
Endereço: Rua 14 de Julho, 85 — Vila Guanabara
Serviços: lavagem interna e externa, hidratação de bancos, higienização, polimento,
vitrificação automotiva, cristalização de pintura e vidros, enceramento,
oxi-sanitização e pintura de moto.
